# Doc Search Instructions
This document provides instructions on how to search for specific information within the documentation.

## Setup
1. Paste the `final.db` into 
```
~/%APPDATA%/Local/DocSearch/final.db`
```
Explanation: This is the directory where the search database is stored. Ensure that you have the correct path based on your operating system.
This path is typically used for applications that store data in the user's local application data directory. This way, the application cannot be 
stolen without the database.

2. Open the Doc Search application.
